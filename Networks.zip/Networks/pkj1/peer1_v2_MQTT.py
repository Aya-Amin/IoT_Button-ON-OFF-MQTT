import paho.mqtt.client as mqtt
import time

# Callback Function on Connection with MQTT Server
Gmessage = []
Number_Of_Messages = 0
y = 0
x = 0
def on_connect( client, userdata, flags, rc):
    print ("Connected with Code :" +str(rc))
    # Subscribe Topic from here
    client.subscribe("IOTc")

# Callback Function on Receiving the Subscribed Topic/Message
def on_message( client, userdata, msg):
    # print the message received from the subscribed topic
    print("here")
    message = str(msg.payload.decode("utf-8"))
    print (message)
    Gmessage.append(message)

#Number_Of_Messages = input()

client = mqtt.Client()

client.username_pw_set("hetxijid", "zrQzrrevIExO")
client.connect("postman.cloudmqtt.com", 18769, 60)
client.on_connect = on_connect
#client.on_message = on_message

client.loop_start()
time.sleep(1)
#while True :
client.on_message = on_message
#    if 'Done' in Gmessage:
 #       print(Gmessage)
  #      Number_Of_Messages = len(Gmessage)
   #     print(Number_Of_Messages)
    #    break
time.sleep(20)
#while (y<Number_Of_Messages+1):
if len(Gmessage) > 0:
    print(Gmessage[0])
    if Gmessage[0] == "The button is pushed":
        client.publish("IOTs","Switch ON led")
else:
    print("No message recieved yet !")
#    if (y-1 == Number_Of_Messages):
 #       break
  #  y = y + 1
client.loop_stop()
client.disconnect()